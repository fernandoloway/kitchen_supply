import React, { Component } from 'react';
import { Link, Route, Router, Redirect } from "react-router-dom";

// import '../styles/Header.css';

import '../../styles/category.css';
import '../../styles/style.css';

import lambloin from '../../assets/products/meats/lambloin.jpg'

class ProductCategory extends Component {
    render() {
        return (
            <div className="Main">

                <main role="main">

                    <section class="jumbotron text-center">
                        <div class="container">
                            <h1 class="jumbotron-heading">Daging</h1>
                            <p class="lead text-muted">Daging yang dijual di KitchenSupply adalah bla bla bla</p>
                            <p>
                                <a href="#" class="btn btn-primary my-2">Tombol</a>
                                <a href="#" class="btn btn-secondary my-2">Tombol 2</a>
                            </p>
                        </div>
                    </section>

                    <div class="album py-5 bg-light">
                        <div class="container">

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="card mb-4 box-shadow">
                                        <Link to="/ProductDetails">
                                            <img class="card-img-top" src={lambloin} alt="gambar" />
                                            <div class="card-body">
                                                <h5 class="card-title">Lamb Loin</h5>
                                                <h6 class="card-subtitle mb-2 text-muted">Rp. 50.000/kg</h6>
                                            </div>
                                        </Link>
                                        <p class="card-text"></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-sm btn-outline-secondary">Tandai</button>
                                                <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                                                <small class="text-muted">9 mins</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card mb-4 box-shadow">
                                        <img class="card-img-top" src={lambloin} alt="gambar" />
                                        <div class="card-body">
                                            <h5 class="card-title">Lamb Loin</h5>
                                            <h6 class="card-subtitle mb-2 text-muted">Rp. 50.000/kg</h6>
                                            <p class="card-text"></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Tandai</button>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                                                </div>
                                                <small class="text-muted">9 mins</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card mb-4 box-shadow">
                                        <img class="card-img-top" src={lambloin} alt="gambar" />
                                        <div class="card-body">
                                            <h5 class="card-title">Lamb Loin</h5>
                                            <h6 class="card-subtitle mb-2 text-muted">Rp. 50.000/kg</h6>
                                            <p class="card-text"></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Tandai</button>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                                                </div>
                                                <small class="text-muted">9 mins</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card mb-4 box-shadow">
                                        <img class="card-img-top" src={lambloin} alt="gambar" />
                                        <div class="card-body">
                                            <h5 class="card-title">Lamb Loin</h5>
                                            <h6 class="card-subtitle mb-2 text-muted">Rp. 50.000/kg</h6>
                                            <p class="card-text"></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Tandai</button>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                                                </div>
                                                <small class="text-muted">9 mins</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card mb-4 box-shadow">
                                        <img class="card-img-top" src={lambloin} alt="gambar" />
                                        <div class="card-body">
                                            <h5 class="card-title">Lamb Loin</h5>
                                            <h6 class="card-subtitle mb-2 text-muted">Rp. 50.000/kg</h6>
                                            <p class="card-text"></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Tandai</button>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                                                </div>
                                                <small class="text-muted">9 mins</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card mb-4 box-shadow">
                                        <img class="card-img-top" src={lambloin} alt="gambar" />
                                        <div class="card-body">
                                            <h5 class="card-title">Lamb Loin</h5>
                                            <h6 class="card-subtitle mb-2 text-muted">Rp. 50.000/kg</h6>
                                            <p class="card-text"></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Tandai</button>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                                                </div>
                                                <small class="text-muted">9 mins</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card mb-4 box-shadow">
                                        <img class="card-img-top" src={lambloin} alt="gambar" />
                                        <div class="card-body">
                                            <h5 class="card-title">Lamb Loin</h5>
                                            <h6 class="card-subtitle mb-2 text-muted">Rp. 50.000/kg</h6>
                                            <p class="card-text"></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Tandai</button>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                                                </div>
                                                <small class="text-muted">9 mins</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card mb-4 box-shadow">
                                        <img class="card-img-top" src={lambloin} alt="gambar" />
                                        <div class="card-body">
                                            <h5 class="card-title">Lamb Loin</h5>
                                            <h6 class="card-subtitle mb-2 text-muted">Rp. 50.000/kg</h6>
                                            <p class="card-text"></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Tandai</button>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                                                </div>
                                                <small class="text-muted">9 mins</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card mb-4 box-shadow">
                                        <img class="card-img-top" src={lambloin} alt="gambar" />
                                        <div class="card-body">
                                            <h5 class="card-title">Lamb Loin</h5>
                                            <h6 class="card-subtitle mb-2 text-muted">Rp. 50.000/kg</h6>
                                            <p class="card-text"></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Tandai</button>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                                                </div>
                                                <small class="text-muted">9 mins</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </main>

            </div>
        );
    }
}


export default ProductCategory;
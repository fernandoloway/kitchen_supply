import React, { Component } from 'react';
import { Link, Route, Router, Redirect } from "react-router-dom";

// import '../styles/Header.css';

import lambloin from '../../assets/products/meats/lambloin.jpg'

import '../../styles/productDetail.css';


class ProductDetails extends Component {
    render() {
        return (
            <div className="Main">

                <main role="main">

                    <div class="container">


                        <hr class="featurette-divider" />

                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><Link to="/Main">Beranda</Link></li>
                                <li class="breadcrumb-item"><Link to="/ProductCategory"> Daging</Link></li>
                                <li class="breadcrumb-item active" aria-current="page">Lamb Loin</li>
                            </ol>
                        </nav>

                        <div class="row featurette">
                            <div class="col-md-5">
                                <img class="featurette-image" src={lambloin} alt="gambar produk" />
                            </div>
                            <div class="col-md-7">
                                <h2 class="featurette-heading">Lamb Loin</h2>
                                <p class="text-muted">Rp. 50.000 /kg.</p>
                                <p class="lead">Daging domba adalah daging yang dihasilkan dari domba yang diternakkan (spesies Ovis aries). Istilah
                                lamb merujuk kepada daging domba muda yang belum berusia satu tahun, yang merupakan jenis daging
                                domba yang paling terkenal. Daging domba muda merupakan domba yang disembelih ketika berusia
                                antara satu bulan hingga satu tahun, dengan berat karkas antara 5.5 hingga 30 kilogram. Daging
                                satu ekor sapi setara dengan daging lima ekor domba.[6] Daging ini umumnya lebih lunak dibandingkan
                                daging domba yang lebih tua, dan umum terdapat di menu masakan negara barat. Daging domba tua
                                dan setengah tua memiliki rasa yang lebih kuat karena mengandung asam lemak yang spesifik terdapat
                                pada domba.[7] Daging domba semakin tua akan semakin alot karena jaringan penghubung yang semakin
                                matang sehingga lebih pantas dimasak ala Casserole, dicincang, atau disemur.</p>
                            </div>
                        </div>

                        <hr class="featurette-divider" />



                    </div>


                </main>

            </div>
        );
    }
}


export default ProductDetails;